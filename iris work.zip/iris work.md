# Iris Data Set 


```python
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
import pandas as pd
from sklearn import tree
from sklearn import metrics
from sklearn.linear_model import SGDClassifier
from sklearn import svm
from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
```


```python
iris  = load_iris()
X  = iris.data
y  = iris.target
```

# Model Evaltion, on Accuracy and Neg log loss


```python
k_range = range (1,31)
k_scores = []
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors =k)
    scores = cross_val_score(knn, X, y, cv =10, scoring = 'accuracy')
    k_scores.append(scores.mean())
```


```python
%matplotlib inline

plt.plot(k_range, k_scores)
plt.xlabel('value of K for KNN')
plt.ylabel("Cross-Validated Accuracy")
```




    Text(0, 0.5, 'Cross-Validated Accuracy')




![png](output_5_1.png)



```python
k_range = range (1,31)
k_scores = []
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors =k)
    scores = cross_val_score(knn, X, y, cv =10, scoring = 'neg_log_loss')
    k_scores.append(scores.mean())

```


```python
%matplotlib inline

plt.plot(k_range, k_scores)
plt.xlabel('value of K for KNN')
plt.ylabel("Cross-Validated neg_log_loss")
# lower is better
```




    Text(0, 0.5, 'Cross-Validated neg_log_loss')




![png](output_7_1.png)


the best value of k is differtn depeding on the metrics
for accurcy it is 20 bceause it produces the highest while for negative log loss is is is alos higher.


```python
leaf_range = range (1,10)
leaf_scores = []
for leaf in leaf_range:
    knn = KNeighborsClassifier(n_neighbors =20, leaf_size = leaf )
    scores = cross_val_score(knn, X, y, cv =10, scoring = 'accuracy')
    leaf_scores.append(scores.mean())
print (leaf_scores)
```

    [0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001, 0.9800000000000001]
    


```python
plt.plot(leaf_range, leaf_scores)
plt.xlabel('amount of leaaves for KNN')
plt.ylabel("Cross-Validated accuracy")
## all the same
```




    Text(0, 0.5, 'Cross-Validated accuracy')




![png](output_10_1.png)


accuracy for differnt leaves


```python
leaf_range = range (1,20)
leaf_scores = []
for leaf in leaf_range:
    knn = KNeighborsClassifier(n_neighbors =20, leaf_size = leaf )
    scores = cross_val_score(knn, X, y, cv =10, scoring =  'neg_log_loss')
    leaf_scores.append(scores.mean())
print (leaf_scores)
```

    [-0.11142551890202393, -0.11142551890202393, -0.11142551890202393, -0.11142551890202393, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11142551890202393, -0.11142551890202393, -0.11142551890202393]
    


```python
plt.plot(leaf_range, leaf_scores)
plt.xlabel('amount of leaaves for KNN')
plt.ylabel("Cross-Validated neg_log_loss")
```




    Text(0, 0.5, 'Cross-Validated neg_log_loss')




![png](output_13_1.png)


neg_log_loss for differnt leaves

the higher leafs are better


```python
leaf_range = range (1,10)
combined_scores = []
for leaf in leaf_range:
    k_range = range (1,31)
    for k in k_range:
        knn = KNeighborsClassifier(n_neighbors =k, leaf_size = leaf)
        scores = cross_val_score(knn, X, y, cv =10, scoring = 'neg_log_loss')
        combined_scores.append(scores.mean())

```


```python
%matplotlib inline
combined_list = range(1,271) 
plt.plot(combined_list, combined_scores)
plt.xlabel('value of K and leafs for KNN')
plt.ylabel("Cross-Validated neg_log_loss")
```




    Text(0, 0.5, 'Cross-Validated neg_log_loss')




![png](output_17_1.png)


# every 30 K is a new leafs, hence the repeation,



```python
leaf_range = range (1,10)
combined_scores = []
for leaf in leaf_range:
    k_range = range (1,31)
    for k in k_range:
        knn = KNeighborsClassifier(n_neighbors =k, leaf_size = leaf)
        scores = cross_val_score(knn, X, y, cv =10, scoring = 'accuracy')
        combined_scores.append(scores.mean())

```


```python
%matplotlib inline
combined_list = range(1,271) 
plt.plot(combined_list, combined_scores)
plt.xlabel('value of K and leafs for KNN')
plt.ylabel("Cross-Validated accuracy")
```




    Text(0, 0.5, 'Cross-Validated accuracy')




![png](output_20_1.png)


# every 30 K is a new leafs, hence the repeation


```python
leaf_range = range (1,10)
combined_scores = []
for leaf in leaf_range:
    k_range = range (1,31)
    for k in k_range:
        knn = KNeighborsClassifier(n_neighbors =k, leaf_size = leaf, p=1)
        scores = cross_val_score(knn, X, y, cv =10, scoring = 'accuracy')
        combined_scores.append(scores.mean())
%matplotlib inline
combined_list = range(1,271) 
plt.plot(combined_list, combined_scores)
plt.xlabel('value of K and leafs for KNN')
plt.ylabel("Cross-Validated accuracy")

```




    Text(0, 0.5, 'Cross-Validated accuracy')




![png](output_22_1.png)


changing distacne to manhattan distance


```python
leaf_range = range (1,10)
combined_scores = []
for leaf in leaf_range:
    k_range = range (1,31)
    for k in k_range:
        knn = KNeighborsClassifier(n_neighbors =k, leaf_size = leaf, p=2)
        scores = cross_val_score(knn, X, y, cv =10, scoring = 'accuracy')
        combined_scores.append(scores.mean())
%matplotlib inline
combined_list = range(1,271) 
plt.plot(combined_list, combined_scores)
plt.xlabel('value of K and leafs for KNN')
plt.ylabel("Cross-Validated accuracy")
```




    Text(0, 0.5, 'Cross-Validated accuracy')




![png](output_24_1.png)


this is euclidean distacnnce


```python
algothim_range = ["auto", "ball_tree", "kd_tree", "brute"]
algothim_scores = []
for a in algothim_range:
        knn = KNeighborsClassifier(n_neighbors =20, leaf_size = 10, algorithm =a, p=2)
        scores = cross_val_score(knn, X, y, cv =10, scoring = 'neg_log_loss')
        algothim_scores.append(scores.mean())
print(algothim_scores)
%matplotlib inline
plt.plot(algothim_range,algothim_scores)
plt.xlabel('algotithm for for KNN')
plt.ylabel("Cross-Validated neg_log_loss")
```

    [-0.11102135475658101, -0.11102135475658101, -0.11102135475658101, -0.11055040966206613]
    




    Text(0, 0.5, 'Cross-Validated neg_log_loss')




![png](output_26_2.png)


so the model is will use is is k =20, leaves = 10, p=2 and alogthim = brute

# data, which charcters are importancant


```python
knnf = KNeighborsClassifier(n_neighbors =20, leaf_size = 10, algorithm = "brute", p=2)
```


```python
feature_list = range(0,4)
feature_score =[]
for f in feature_list:
        scores = cross_val_score(knn,  [[feature_list[f]] for feature_list in iris.data], y, cv =10, scoring = 'accuracy')
        feature_score.append(scores.mean())
        print(feature_score)
%matplotlib inline
plt.plot(feature_list,feature_score)
plt.xlabel('feature of data')
plt.ylabel("Cross-Validated accuracy")
```

    [0.74]
    [0.74, 0.5733333333333334]
    [0.74, 0.5733333333333334, 0.9533333333333334]
    [0.74, 0.5733333333333334, 0.9533333333333334, 0.9600000000000002]
    




    Text(0, 0.5, 'Cross-Validated accuracy')




![png](output_30_2.png)



```python
feature_list = range(0,4)
feature_score =[]
for f in feature_list:
        scores = cross_val_score(knn,  [[feature_list[f]] for feature_list in iris.data], y, cv =10, scoring = 'neg_log_loss')
        feature_score.append(scores.mean())
        print(feature_score)
%matplotlib inline
plt.plot(feature_list,feature_score)
plt.xlabel('feature of data')
plt.ylabel("Cross-Validated Neagtive Logartimic loss")
```

    [-0.8478580099234371]
    [-0.8478580099234371, -1.2879354014273794]
    [-0.8478580099234371, -1.2879354014273794, -0.33500888435195353]
    [-0.8478580099234371, -1.2879354014273794, -0.33500888435195353, -0.32955552787178877]
    




    Text(0, 0.5, 'Cross-Validated Neagtive Logartimic loss')




![png](output_31_2.png)


this shows that the lst 2 features help make a much mork accuracte model


```python
f5 = [list(feature_list[:2]) for feature_list in iris.data]
# features 1,2 index 0-1
scores = cross_val_score(knnf,  f5, y, cv =10, scoring = 'accuracy')
print(scores.mean())
        
```

    0.7866666666666666
    


```python
f6 = [list(feature_list[2:4]) for feature_list in iris.data]
# features 3,4 index 2-3
scores = cross_val_score(knnf,  f6, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.96
    


```python
f7 = [[feature_list[1]]+ [feature_list[2]] for feature_list in iris.data]
# features 2 3, index 1-2
scores = cross_val_score(knnf,  f7, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9533333333333334
    


```python
f8 = [[feature_list[0]]+ [feature_list[3]] for feature_list in iris.data]

# features 1 4, index 0 and 3
scores = cross_val_score(knnf,  f8, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9533333333333334
    


```python
f9 = [[feature_list[0]]+ [feature_list[2]] for feature_list in iris.data]
# features 1 3, index 0 and 2
scores = cross_val_score(knnf,  f9, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9400000000000001
    


```python
f10 = [[feature_list[1]]+ [feature_list[3]] for feature_list in iris.data]
# features 2 4, index 1 and 3
scores = cross_val_score(knnf,  f10, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9666666666666668
    


```python
f11 = [list(feature_list[0:3]) for feature_list in iris.data]
# features 1,2,3 index 0-2
scores = cross_val_score(knnf,  f11, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9466666666666667
    


```python
f12 = [list(feature_list[1:4]) for feature_list in iris.data]
# features 2,3,4 index 1-3
scores = cross_val_score(knnf,  f12, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9600000000000002
    


```python
f13 =  [list(feature_list[0:2])+[feature_list[3]] for feature_list in iris.data]
# features 1,2,4 index 0-2 and 3
scores = cross_val_score(knnf,  f13, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.9400000000000001
    


```python
f14 =[[feature_list[0]] + list(feature_list[2:4]) for feature_list in iris.data]
# features 1,3,4 index 0 and 2-3
scores = cross_val_score(knnf,  f14, y, cv =10, scoring = 'accuracy')
print(scores.mean())
```

    0.96
    


```python
scores = cross_val_score(knnf,  X, y, cv =10, scoring = 'accuracy')
print(scores.mean())
# all features
```

    0.9800000000000001
    
